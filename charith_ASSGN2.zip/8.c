#include <stdio.h>

int main()

{   
    int a;
    label:
    printf("please enter a +ve number:");
    scanf("%d",&a);
    if(a<=0)
    {
        goto label;
    }
    if(a>0)
    {
        printf("ENDING ....");
    }
    return 0;

}