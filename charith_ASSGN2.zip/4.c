#include <stdio.h>
enum days{monday=1,tuesday,wednesday,thursday,friday,saturday,sunday};
int main()
{   int a;
    printf("--Enter Number in (1-7) :\n");
    scanf("%d",&a);
    switch(a)
    {
         case monday   : printf("monday!");
                     break;
         case tuesday  : printf("tuesday!");
                     break;
         case wednesday: printf("wednesday!");
                     break;
         case thursday : printf("thursday!");
                     break;
         case friday   : printf("friday!");
                     break;
         case saturday : printf("monday!");
                     break;
         case sunday   : printf("sunday!");
                     break; 
         default: printf("it is not a daY!sorry");            
    }
  
    return 0;

}