#include <stdio.h>
#define PI 3.14159
int main()
{
    float r,area;
    printf("++Enter radius of the circle :");
    scanf("%f",&r);
    area=PI*r*r;
    printf("AREA of the circle is :%f",area);
    return 0;

}