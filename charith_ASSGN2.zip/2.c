#include <stdio.h>
//q.2
int main()
{
   int a,b;
   float c;
   printf("Enter an ->integer and ->floating number : \n");
   scanf("%d %f",&a,&c);
   printf("%d %f",(int) c,(float)a);
   return 0;
}